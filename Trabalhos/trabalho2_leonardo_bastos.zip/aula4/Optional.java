package br.com.prog3.aula4;

public @interface Optional {
}
