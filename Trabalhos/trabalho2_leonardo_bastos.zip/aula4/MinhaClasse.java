package br.com.prog3.aula4;

@MinhaAnotacao(nome = "Carol",idade = 20,novosNomes = {"Ana Clara, Maria da Silva"})
public class MinhaClasse {
}
