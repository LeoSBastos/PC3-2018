package br.com.prog3.aula5;

public enum TipoPessoa {
    PESSOA_FISICA,PESSOA_JURIDICA
}
